<?php

namespace App\Http\Controllers\Admin;

use App\Models\Customer; 
use App\Http\Controllers\Controller; 


class EnquiryController extends Controller
{
  
}
