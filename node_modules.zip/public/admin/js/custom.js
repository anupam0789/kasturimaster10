$(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })

    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
    $("input[data-bootstrap-switch]").each(function(){
      $(this).bootstrapSwitch('state', $(this).prop('checked'));
    })
  });

  //Loader Js
  document.addEventListener("DOMContentLoaded", function() {
    var loadContentLink = document.getElementById('loadContentLink');
    var loaderContainer = document.getElementById('loaderContainer');
    var content = document.getElementById('content');

    loadContentLink.addEventListener('click', function(event) {
        event.preventDefault();
        showLoader();
        
        // Simulate content loading delay (Replace this with actual content loading)
        setTimeout(function() {
            hideLoader();
            content.style.display = 'block';
            content.innerHTML = '<h2>Content Loaded!</h2>';
        }, 2000); // 2000 milliseconds (2 seconds) delay
    });

    function showLoader() {
        loaderContainer.style.display = 'flex';
    }

    function hideLoader() {
        loaderContainer.style.display = 'none';
    }
});